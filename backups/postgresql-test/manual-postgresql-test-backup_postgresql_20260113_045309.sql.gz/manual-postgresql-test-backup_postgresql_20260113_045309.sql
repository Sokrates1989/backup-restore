--
-- PostgreSQL database dump
--

\restrict Sk7z98DKkwyHxQRDNqhzS5ECdFTQYvjBGg0258GIlECP5IwPtEQDbFQ5ARFfkyc

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: test; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test (
    "ID" bigint NOT NULL,
    name text
);


--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test ("ID", name) FROM stdin;
0	test
1	test1
\.


--
-- Name: test test_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test
    ADD CONSTRAINT test_pkey PRIMARY KEY ("ID");


--
-- PostgreSQL database dump complete
--

\unrestrict Sk7z98DKkwyHxQRDNqhzS5ECdFTQYvjBGg0258GIlECP5IwPtEQDbFQ5ARFfkyc

